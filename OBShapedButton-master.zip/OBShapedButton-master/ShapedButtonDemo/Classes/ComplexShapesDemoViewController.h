//
//  ComplexShapesDemoViewController.h
//  ShapedButtonDemo
//
//  Created by Ole Begemann on 24.04.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ComplexShapesDemoViewController : UIViewController
@end
