//
//  main.m
//  ShapedButtonDemo
//
//  Created by Ole Begemann on 17.10.09.
//  Copyright Ole Begemann 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, nil);
    }
}
