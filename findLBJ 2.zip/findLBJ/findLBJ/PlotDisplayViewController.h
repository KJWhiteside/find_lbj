//
//  PlotDisplayViewController.h
//  findLBJ
//
//  Created by Kevin Whiteside on 3/28/14.
//  Copyright (c) 2014 App-t Pupils. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Course.h"

@interface PlotDisplayViewController : UIViewController

@property Course* course;
@end
